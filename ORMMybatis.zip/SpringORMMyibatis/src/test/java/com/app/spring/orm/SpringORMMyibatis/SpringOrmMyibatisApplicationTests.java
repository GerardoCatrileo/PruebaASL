package com.app.spring.orm.SpringORMMyibatis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringOrmMyibatisApplicationTests {

	@Test
	void contextLoads() {
	}

}
